
//Listado y elección de acciones favoritas
function listarFavoritas(){
    const listadoFavoritas = document.getElementById("listadoFavoritas");
    let liId = ""
    let acumuladorFav ='<h2>Selección de favoritas</h2><ul class="list-group listadoFavoritasContenedor"> '
    for (let index = 0; index < arrayAcciones.length; index++) {
        checkId = `check${index}`;
        acumuladorFav += `
        <li class="list-group-item listadoFavoritas">
        <input id="${checkId}" class="form-check-input me-1" type="checkbox" value="" aria-label="...">
        ${arrayAcciones[index].ticker}
        </li>
        `  
    }
    acumuladorFav +='</ul>'
    listadoFavoritas.innerHTML = acumuladorFav;
  }

  
//Contenedor de Favoritas
const constructorFavoritas = function(){
    const contenedorFavoritas = document.getElementById("contenedorFavoritas");
      let acumuladorFavElegidas = `<div class="tarjetas">
                                <div class="card" style="width: 27rem;">
                                <div class="card-header">
                                Acciones Favoritas
                                </div>
                                <ul class="list-group list-group-flush">`

        for (let index = 0; index < arrayAccionesFavElegidas.length; index++) {
            acumuladorFavElegidas += `
            <li class="list-group-item">${arrayAccionesFavElegidas[index].ticker}   Precio: ${arrayAccionesFavElegidas[index].precio}    MACD: ${arrayAccionesFavElegidas[index].macd} RSI: ${arrayAccionesFavElegidas[index].rsi} %WMA21: ${arrayAccionesFavElegidas[index].wma21} </li>
            `
        }
        acumuladorFavElegidas +=`</ul></div></div>`
        if (arrayAccionesFavElegidas.length > 0) {
          contenedorFavoritas.innerHTML = acumuladorFavElegidas;
        }
        else{
        contenedorFavoritas.innerHTML = ``;
        }
        localStorage.setItem("arrayAccionesFavElegidas",JSON.stringify(arrayAccionesFavElegidas))
}


//Contenedor de Tenencias
const constructorTenencias = function(){
    const contenedorTenencia = document.getElementById("listadoTenencia");
    let acumuladorTenencia = `<div class="tarjetas">
                                <div class="contenedorTenencia card">
                                <div class="card-header">
                                Tenencia en Cartera
                                </div>
                                <ul class="list-group list-group-flush">`
          for (let index = 0; index < arrayTenencias.length; index++) {
  
                if (arrayTenencias[index].difprecioTenencia >= 0){
                      acumuladorTenencia+= `
                      <li class="list-group-item">Ticker: ${arrayTenencias[index].ticker}  Cantidad: ${arrayTenencias[index].cantidad} Precio: ${arrayTenencias[index].precio} Variación: <span class="badge bg-success">${arrayTenencias[index].difprecioTenencia}%</span>
                      `
                }else{
                  acumuladorTenencia+= `
                  <li class="list-group-item">Ticker: ${arrayTenencias[index].ticker}  Cantidad: ${arrayTenencias[index].cantidad} Precio: ${arrayTenencias[index].precio} Variación: <span class="badge bg-danger">${arrayTenencias[index].difprecioTenencia}%</span>
                  `
                }                
                      //Botón Borrar
                      acumuladorTenencia+=
                      `<button type="button" ref=${arrayTenencias[index].id} class="btnBorrar btn-close" aria-label="Cerrar"></button></li>`;
                      }
                    
        acumuladorTenencia +=`</ul></div></div>`
        contenedorTenencia.innerHTML = acumuladorTenencia;   
  
          //Quitar tenencia
          btnBorrar = document.querySelectorAll(".btnBorrar");
          btnBorrar.forEach(el => el.addEventListener("click",borrarTenencia));
          if (arrayTenencias.length == 0) {
            contenedorTenencia.innerHTML = "";
          }
  }

  //Card con todas las acciones
function dashCompleto(){
    let arrayBolsas = [...arrayAcciones].sort((a,b)=>b.D1 - a.D1);
    let contenedorTodas = 
                    `<div class="tarjetas bolsaAcc">
                      <div class="contenedorTenencia card">
                      <div class="card-header">
                      <h3>Bolsa de acciones</h3></div>
                      <ul class="list-group list-group-flush">`

    for (let index = 0; index < arrayBolsas.length; index++) {

      switch (true) {
        case (arrayBolsas[index].D1 > 0):
          contenedorTodas += `<li class="list-group-item rengAcc"><span class="badge rounded-pill bg-light text-dark">${arrayBolsas[index].ticker}</span> Bolsa: ${arrayBolsas[index].bolsa} Ind: ${arrayBolsas[index].industria} <span class="badge bg-success">D1: ${arrayBolsas[index].D1}%</span></li>`
          break;
        case (arrayBolsas[index].D1 <= 0 && arrayBolsas[index].D1 >= -2):
          contenedorTodas += `<li class="list-group-item rengAcc"><span class="badge rounded-pill bg-light text-dark">${arrayBolsas[index].ticker}</span> Bolsa: ${arrayBolsas[index].bolsa} Ind: ${arrayBolsas[index].industria} <span class="badge bg-warning">D1: ${arrayBolsas[index].D1}%</span></li>`
          break;
        case (arrayBolsas[index].D1 < -2):
          contenedorTodas += `<li class="list-group-item rengAcc"><span class="badge rounded-pill bg-light text-dark">${arrayBolsas[index].ticker}</span> Bolsa: ${arrayBolsas[index].bolsa} Ind: ${arrayBolsas[index].industria} <span class="badge bg-danger">D1: ${arrayBolsas[index].D1}%</span></li>`
          break;
      }  
    }
    $(".bodyInd").append(contenedorTodas);
};