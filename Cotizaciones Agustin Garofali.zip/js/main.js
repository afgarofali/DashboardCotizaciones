//Carga asíncrona de información de acciones desde origen local (acciones.json)
let arrayAcciones = [];
let arrayIndicadores = [];
$.get('data/acciones.json',function(datos, estado){
  if(estado == 'success'){
      for (const literal of datos) {
        arrayAcciones.push(new Accion(literal.id, literal.ticker, literal.precio, literal.industria, literal.bolsa, literal.macd, literal.rsi, literal.wma21, literal.D1));
      }
  }
  //Ordenar arrays segun propiedades del objeto acción
//let arrayAcciones = [accion1,accion2,accion3,accion4, accion5, accion6, accion7, accion8, accion9];
let arrayMacd = [...arrayAcciones].sort((a,b)=>a.macd - b.macd);
let arrayRsi = [...arrayAcciones].sort((a,b)=>a.rsi - b.rsi);
let arrayWma21 = [...arrayAcciones].sort((a,b)=>a.wma21 - b.wma21);
arrayIndicadores = [arrayMacd,arrayRsi,arrayWma21];
renderizarTarjetas(nombresTarjetas);
listarFavoritas();
dashCompleto();
});


//Armado y config del HTML

const nombresTarjetas = ["Por MACD", "Por RSI", "Por % WMA21"]
const contenedor = document.getElementById("contenedor");

const renderizarTarjetas = (nombresTarjetas) =>{let acumulador ='<div class="tarjetas">'
    for (let index = 0; index < nombresTarjetas.length; index++) {
        acumulador += `
        <div class="card" style="width: 18rem;">
        <div class="card-header">
        ${nombresTarjetas[index]}
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item cardInd">${arrayIndicadores[index][0].ticker}</li>
          <li class="list-group-item cardInd">${arrayIndicadores[index][1].ticker}</li>
          <li class="list-group-item cardInd">${arrayIndicadores[index][2].ticker}</li>
          <li class="list-group-item cardInd">${arrayIndicadores[index][3].ticker}</li>
        </ul>
      </div>`    
    }
    acumulador +='</div>'
    contenedor.innerHTML = acumulador
}


//Agregar Favoritas a localstorage
let arrayAccionesFavElegidas = [];
if(localStorage.getItem("arrayAccionesFavElegidas")){
  arrayAccionesFavElegidas = JSON.parse(localStorage.getItem("arrayAccionesFavElegidas"));
}



//Botón Favoritas
checkId = "";
const botonFav = document.getElementById("botonFavoritas");
botonFav.addEventListener("click", function(){
    for (let index = 0; index < arrayAcciones.length; index++) {
        checkId = `check${index}`;
        if (document.getElementById(checkId).checked == true) {
            arrayAccionesFavElegidas.push(arrayAcciones[index]);
            constructorFavoritas();
          }
        else{
          constructorFavoritas();
            } 
    }
    arrayAccionesFavElegidas.length = 0;
    $("#contenedorFavoritas").fadeOut(150).fadeIn(1000);
})


//Agregar Tenencias a localstorage
let arrayTenencias = [];
if(localStorage.getItem("arrayTenencias")){
  arrayTenencias = JSON.parse(localStorage.getItem("arrayTenencias"));
}

let idTenencia = 0;

//Botón Agregar Tenencia
const botonTenencia = document.getElementById("botonTenencia");
botonTenencia.addEventListener("click", function(){
  let tickerTenencia = document.getElementById("tickerTenencia").value;
  let cantidadTenencia = document.getElementById("cantidadTenencia").value;
  let precioTenencia = document.getElementById("precioTenencia").value;
  let difprecioTenencia = 0;

  tickerTenencia = tickerTenencia.toUpperCase();

  for (let i = 0; i < arrayAcciones.length; i++) {
       if (tickerTenencia == arrayAcciones[i].ticker) {
         console.log("hay coincidencia");
         difprecioTenencia = Math.round((arrayAcciones[i].precio*100/precioTenencia)-100);
         console.log("difprecioTenencia:",difprecioTenencia);
     }
  } 
  const tenencia = new Tenencia(idTenencia, tickerTenencia, cantidadTenencia, precioTenencia, difprecioTenencia);
  difprecioTenencia = 0;
  idTenencia +=1;
  arrayTenencias.push(tenencia);
  constructorTenencias();
  $("#listadoTenencia").fadeOut(150).fadeIn(1000);
  localStorage.setItem("arrayTenencias",JSON.stringify(arrayTenencias))

})

//Botón Mostrar Tenencia
const mostrarTenencia = document.getElementById("mostrarTenencia");
mostrarTenencia.addEventListener("click", function(){
      constructorTenencias();  
      $("#listadoTenencia").show();
}) 


//Botón Ocultar Tenencia
const ocultarTenencia = document.getElementById("ocultarTenencia");
ocultarTenencia.addEventListener("click", function(){
    $("#listadoTenencia").hide();
})



//Borrar tenencia
const borrarTenencia = (e) =>{
  let id = parseInt(e.target.getAttribute("ref"))
  let seleccion = arrayTenencias.find(item => item.id === id);
  let aux = arrayTenencias.filter(el => el.id !== seleccion.id);
  arrayTenencias = aux;
  localStorage.setItem("arrayTenencias",JSON.stringify(arrayTenencias));
  constructorTenencias();

}





//Animaciones de intro

$(".bodyInd").hide()

$(".spinner").fadeOut(3500);

$(".bodyInd").show(2000).fadeIn(2000);







